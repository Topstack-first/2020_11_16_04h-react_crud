import React from 'react';
import './App.css';
import { ReactComponent as Logo } from './logo.svg';

  const AppHeader = (props) => {
    return (  
      <div className="AppHeader row">
          <div className="col-1"><Logo/></div>
          <div className="col-9"><h1 className="center">Javascript Frameworks</h1></div>
          <button className="col-1 btn mt-2 AppHeader" onClick={props.goToNewItem }> + New Item </button>
      </div>
      
    );
  }
export default AppHeader;