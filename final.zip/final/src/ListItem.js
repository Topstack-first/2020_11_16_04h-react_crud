import React from 'react';
import './App.css';

  const ListItem = (props) => {
    return (  
        <div className="ListItem">
            <div className="row" >
                <h2 className="col-2 LeftAlign">{props.listItem.framework_name}</h2>
                <div className="col-7 LeftAlign"></div>
                <button className="col-1 btn btn-primary ml-2 EditBtn" onClick={()=>props.editItem(props.listItem)}>Edit</button>
            </div>
            <div className="row" >
                <span className="col-2 LeftAlign">lead by {props.listItem.lead_by}</span>
                <div className="col-7 LeftAlign"><a href={props.listItem.docs_url}>Official Docs</a></div>
                <button className="col-1 btn btn-danger ml-2 DeleteBtn" onClick={()=>props.deleteItem(props.listItem.id)}>Delete</button>
            </div>
        </div>
      
    );
  }
export default ListItem;