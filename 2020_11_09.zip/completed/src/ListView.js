import React from 'react';
import ListItem from './ListItem'

  const ListView = (props) => {
    return (  
            
              props.listItems.length > 0 ? (
                props.listItems.map((listItem) => (
                    <ListItem
                      listItem = {listItem}
                      deleteItem={props.deleteItem}
                      editItem={props.editItem}
                      setEditable={props.setEditable}
                    />
                  )
                )
              ) : (
                <div></div>
              )
            
    );
  }
export default ListView;


