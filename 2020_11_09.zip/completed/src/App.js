import React, { useState } from 'react';
import AppHeader from './AppHeader';
import './App.css';
import ListView from './ListView';
import NewItemView from './NewItemView';
import { thisExpression, throwStatement } from '@babel/types';


function App (){
  const [id,setId]  = useState(null);
  const [framework_name,setFrameworkName]  = useState(null);
  const [docs_url,setDocsUrl]  = useState('');
  const [lead_by,setLeadBy]  = useState('');
  const [editMode,setEditMode]  = useState(false);
  const [newMode,setNewMode]  = useState(false);
  const [listItem,setListItem]  = useState({});
  const [listItems,setListItems]  = useState([]);

  function handleInputChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
 
    if(name === "framework_name")
    {
      setFrameworkName(value);
    }
    else if(name === "docs_url")
    {
      setDocsUrl(value);
    }
    if(name === "lead_by")
    {
      setLeadBy(value);
    }
  }
  function saveNewItem(event)
  {
    event.preventDefault()
    if (!framework_name) return;
    const listItem = {
      id: listItems.length + 1,
      framework_name: framework_name,
      docs_url: docs_url,
      lead_by: lead_by,
    };
    setFrameworkName('');
    setDocsUrl('');
    setLeadBy('');
    setListItem(listItem);
    setListItems([...listItems, listItem]);
    
    setNew(false);
  }
  function goToNewItem(event){
    setNew(true);
  }
  function setNew(is_new)
  {
    if(typeof is_new !== 'boolean') { throw " This value must either be true or false"}
    setNewMode(is_new);
  }
  function setEditable(is_editable)
  {
    if(typeof is_editable !== 'boolean') { throw " This value must either be true or false"}
    setEditMode(is_editable);
  }
  function deleteItem(id)
  {
    const newListItems = listItems.filter( item => item.id !== id );
    setListItems(newListItems);
    if(editMode === true) {
      setEditable(false);
    }
  }
  function editItem(listItem)
  {
    setEditable(true);
    setFrameworkName(listItem.framework_name);
    setDocsUrl(listItem.docs_url);
    setLeadBy(listItem.lead_by);
    setListItem(listItem);
  }
  function updateListItem(event) {
    event.preventDefault();
    const updated_framework_name = framework_name;
    const updated_docs_url = docs_url;
    const updated_lead_by = lead_by;
    const updatedListItem = Object.assign({}, listItem, { framework_name: updated_framework_name, docs_url: updated_docs_url,lead_by: updated_lead_by });
    const newListItems = listItems.map((listItem) => (listItem.id === listItem.id ? updatedListItem : listItem));
    setFrameworkName('');
    setDocsUrl('');
    setLeadBy('');
    setListItems(newListItems);
    setEditable(false);
  }
  return (
    <div className="App">
        <AppHeader
        goToNewItem={goToNewItem}
        />
      {
        newMode ? (
          <NewItemView
          framework_name = {framework_name}
          docs_url = {docs_url}
          lead_by = {lead_by}
          handleInputChange = {handleInputChange}
          setNew = {setNew}
          saveNewItem = {saveNewItem}
          />
          
        ) : (
          <ListView
          editItem={editItem}
          setEditable={setEditable}
          deleteItem={deleteItem}
          listItems={listItems} 
          />
        )
      }
      
      {
        editMode ? (<div className="Padding">
        <div className="row Padding">
            <label className="col-4 RightAlign">Framework Name</label>
            <input type="text" className="col-6 form-control " name="framework_name" value={framework_name} onChange={ handleInputChange}/>
            <div className="col-2"></div>
        </div>
        <div className="row Padding">
            <label className="col-4 RightAlign">Docs Url</label>
            <input type="text" className="col-6 form-control " name="docs_url" value={docs_url} onChange={ handleInputChange}/>
            <button className="col-1 btn btn-primary ml-2 EditBtn" onClick={ updateListItem }>Save</button>
        </div>
        <div className="row Padding">
            <label className="col-4 RightAlign">Lead By</label>
            <input type="text" className="col-6 form-control " name="lead_by" value={lead_by} onChange={ handleInputChange}/>
            <button className="col-1 btn btn-danger ml-2 DeleteBtn" onClick={() => setEditable(false)}>Cancel</button>
        </div>
      </div> ) : (<div></div>)
      }
      
    </div>
  );
}


export default App;
