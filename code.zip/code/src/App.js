import React from 'react';
import AppHeader from './AppHeader';
import './App.css';
import ListView from './ListView';
import NewItemView from './NewItemView';
import { thisExpression, throwStatement } from '@babel/types';


class App extends React.Component {

  constructor() {
    super();
    this.state = {
      id: null,
      framework_name:'',
      docs_url:'',
      lead_by:'',
      editMode: false,
      newMode:false,
      listItem: {},
      listItems: [],
    };

    this.goToNewItem = this.goToNewItem.bind(this);
    this.setNew = this.setNew.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
    this.saveNewItem = this.saveNewItem.bind(this);
    this.setEditable = this.setEditable.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
    this.editItem = this.editItem.bind(this);
    this.updateListItem = this.updateListItem.bind(this);
  }
  handleInputChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
 
    this.setState({
      [name]:value
    })
  }
  saveNewItem(event)
  {
    event.preventDefault()
    if (!this.state.framework_name) return;
    const listItem = {
      id: this.state.listItems.length + 1,
      framework_name: this.state.framework_name,
      docs_url: this.state.docs_url,
      lead_by: this.state.lead_by,
    };

    this.setState({
      framework_name: '',
      docs_url: '',
      lead_by:'',
      listItem: listItem,
      listItems: [...this.state.listItems, listItem]
    })
    this.setNew(false);
  }
  goToNewItem(event){
    this.setNew(true);
  }
  setNew(is_new)
  {
    if(typeof is_new !== 'boolean') { throw " This value must either be true or false"}
    this.setState({
      newMode:is_new
    });
  }
  setEditable(is_editable)
  {
    if(typeof is_editable !== 'boolean') { throw " This value must either be true or false"}
    this.setState({
      editMode:is_editable
    });
  }
  deleteItem(id)
  {
    const listItems = this.state.listItems.filter( item => item.id !== id );
    this.setState({listItems: listItems});
    if(this.state.editMode === true) {
      this.setEditable(false);
    }
  }
  editItem(listItem)
  {
    this.setEditable(true);
    this.setState({
      framework_name:listItem.framework_name,
      docs_url:listItem.docs_url,
      lead_by : listItem.lead_by,
      listItem: listItem
    });
  }
  updateListItem(event) {
    event.preventDefault();
    const updated_framework_name = this.state.framework_name;
    const updated_docs_url = this.state.docs_url;
    const updated_lead_by = this.state.lead_by;
    const updatedListItem = Object.assign({}, this.state.listItem, { framework_name: updated_framework_name, docs_url: updated_docs_url,lead_by: updated_lead_by });
    const listItems = this.state.listItems.map((listItem) => (listItem.id === this.state.listItem.id ? updatedListItem : listItem));
    this.setState({ framework_name:'', docs_url: '',lead_by:'', listItems: listItems});
    this.setEditable(false);
  }
  render() {
    const { editMode,newMode,listItems } = this.state;
      return (
        <div className="App">
		      <header className="App-header">
            <AppHeader
            goToNewItem={this.goToNewItem}
            />
      		</header>
          {
            newMode ? (
              <NewItemView
              framework_name = {this.state.framework_name}
              docs_url = {this.state.docs_url}
              lead_by = {this.state.lead_by}
              handleInputChange = {this.handleInputChange}
              setNew = {this.setNew}
              saveNewItem = {this.saveNewItem}
              />
              
            ) : (
              <ListView
              editItem={this.editItem}
              setEditable={this.setEditable}
              deleteItem={this.deleteItem}
              listItems={listItems} 
              />
            )
          }
          
          {
            editMode ? (<div className="Padding">
            <div className="row Padding">
                <label className="col-4 RightAlign">Framework Name</label>
                <input type="text" className="col-6 form-control " name="framework_name" value={this.state.framework_name} onChange={ this.handleInputChange}/>
                <div className="col-2"></div>
            </div>
            <div className="row Padding">
                <label className="col-4 RightAlign">Docs Url</label>
                <input type="text" className="col-6 form-control " name="docs_url" value={this.state.docs_url} onChange={ this.handleInputChange}/>
                <button className="col-1 btn btn-primary ml-2 EditBtn" onClick={ this.updateListItem }>Save</button>
            </div>
            <div className="row Padding">
                <label className="col-4 RightAlign">Lead By</label>
                <input type="text" className="col-6 form-control " name="lead_by" value={this.state.lead_by} onChange={ this.handleInputChange}/>
                <button className="col-1 btn btn-danger ml-2 DeleteBtn" onClick={() => this.setEditable(false)}>Cancel</button>
            </div>
          </div> ) : (<div></div>)
          }
          
        </div>
      );
    }
}


export default App;
