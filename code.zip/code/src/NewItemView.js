import React from 'react';
import './App.css';

  const NewItemView = (props) => {
    return (  
        <div>
            <h1>Add a new framework</h1>
            <div className="row Padding">
                <label className="col-4 RightAlign">Framework Name</label>
                <input type="text" className="col-6 form-control " name="framework_name"  value={props.framework_name} onChange={ props.handleInputChange}/>
                <div className="col-2"></div>
            </div>
            <div className="row Padding">
                <label className="col-4 RightAlign">Docs Url</label>
                <input type="text" className="col-6 form-control " name="docs_url"  value={props.docs_rul} onChange={ props.handleInputChange}/>
                <button className="col-1 btn btn-primary ml-2 EditBtn" onClick={props.saveNewItem}>Save</button>
            </div>
            <div className="row Padding">
                <label className="col-4 RightAlign">Lead By</label>
                <input type="text" className="col-6 form-control " name="lead_by"  value={props.lead_by} onChange={ props.handleInputChange}/>
                <button className="col-1 btn btn-danger ml-2 DeleteBtn" onClick={() => props.setNew(false)}>Cancel</button>
            </div>
        </div>
        
    );
  }
export default NewItemView;