import { Dispatcher } from 'flux';

const AppDispatcher = new Dispatcher(); 

export default AppDispatcher;
