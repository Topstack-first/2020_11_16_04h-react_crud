import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./TodoDetails.css";
function TodoDetails() {
  const [todo, setTodo] = useState();

  useEffect(() => {
    getTodoData().then((response) => setTodo(response));
  }, []);

  async function getTodoData() {
    const URL = `https://jsonplaceholder.typicode.com/todos/`;

    try {
      const response = await fetch(URL);
      if (!response.ok) throw new Error(response.statusText);

      return response.json();
    } catch (error) {}
  }

  const { id } = useParams();
  let todoData;

  if (!todo) {
    return null;
  }
  const todoFilter = todo.filter((data) => data.userId === parseInt(id));

  if (id) {
    todoData = todoFilter.map((data) => (
      <div className="todo" key={data.id}>
        {data.title}
      </div>
    ));
  } else {
    todoData = todo.map((data) => (
      <div className="todo" key={data.id}>
        {data.title}
      </div>
    ));
  }

  return (
    <div className="grid">
      <h1>Todos</h1>
      {todoData}
    </div>
  );
}
export default TodoDetails;
