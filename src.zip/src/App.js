import React from "react";
import { HashRouter as Router, NavLink, Route, Switch } from "react-router-dom";
import UserDetails from "./UserDetails.js";
import TodoDetails from "./TodoDetails.js";
import AlbumDetails from "./AlbumDetails.js";

import "./App.css";

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <NavLink className="nav" to="/">
            Users
          </NavLink>
          <> </>
          <NavLink className="nav" to="/todos">
            Todos
          </NavLink>
          <> </>
          <NavLink className="nav" to="/albums">
            Albums
          </NavLink>
          <> </>
        </nav>
        <main>
          <Switch>
                        
            <Route path="/users/:id/albums">
                            
              <AlbumDetails />
                          
            </Route>
                        
            <Route path="/albums">
                            
              <AlbumDetails />
                          
            </Route>
                        
            <Route path="/users/:id/todos">
                            
              <TodoDetails />
                          
            </Route>
                        
            <Route path="/todos">
                            
              <TodoDetails />
                          
            </Route>
                        
            <Route path="/users/:id">
                            
              <UserDetails />
                          
            </Route>
                        
            <Route path="/">
                            
              <UserDetails />
                          
            </Route>
                      
          </Switch>
        </main>
      </div>
    </Router>
  );
}

export default App;
