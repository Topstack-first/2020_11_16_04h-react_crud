import React, { useEffect, useState } from "react";
import { BrowserRouter as Link, NavLink, useParams } from "react-router-dom";
import image from "./avatar-1.png";
import "./UserDetails.css";
function UserDetails() {
  const [user, setUser] = useState();

  useEffect(() => {
    getUserData().then((response) => setUser(response));
  }, []);

  async function getUserData() {
    const URL = `https://jsonplaceholder.typicode.com/users`;

    try {
      const response = await fetch(URL);
      if (!response.ok) throw new Error(response.statusText);

      return response.json();
    } catch (error) {}
  }

  const { id } = useParams();
  if (!user) {
    return null;
  }

  const userList = user.filter((data) => data.id === parseInt(id));

  let userData;

  if (id) {
    userData = userList.map((data) => (
      <div className="card detail" key={data.id}>
        <img src={image} alt="profile" className="img" />
        <h2>{data.name}</h2>

        <p>Email: {data.email}</p>
        <p>Website: {data.website}</p>
        <p>Phone: {data.phone}</p>
        <p>Company: {data.company.name}</p>
        <div>
          <NavLink to={`/users/${data.id}/albums`}>
            <button>Albums</button>
          </NavLink>
          <> </>
          <NavLink to={`/users/${data.id}/todos`}>
            <button>Todo</button>
          </NavLink>
        </div>
      </div>
    ));
  } else {
    userData = user.map((data) => (
      <div key={data.id}>
        <div className="card">
          <NavLink className="link" to={`/users/${data.id}`}>
            <img src={image} alt="profile" className="img" />
            <div className="container">
              <h2> {data.name}</h2>
              <p>{data.email}</p>
            </div>
          </NavLink>
          <div className="buttons">
            <NavLink to={`/users/${data.id}/albums`}>
              <button>Albums</button>
            </NavLink>
            <> </>
            <NavLink to={`/users/${data.id}/todos`}>
              <button>Todo</button>
            </NavLink>
          </div>
        </div>
      </div>
    ));
  }

  return (
    <div className="grid">
      <h1>Users</h1>
      <div>{userData}</div>
    </div>
  );
}

export default UserDetails;
