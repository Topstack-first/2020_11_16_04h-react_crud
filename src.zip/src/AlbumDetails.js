import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./AlbumDetails.css";
function AlbumDetails() {
  const [album, setAlbums] = useState();

  useEffect(() => {
    getAlbumData().then((response) => setAlbums(response));
  }, []);

  async function getAlbumData() {
    const URL = `https://jsonplaceholder.typicode.com/albums/`;

    try {
      const response = await fetch(URL);
      if (!response.ok) throw new Error(response.statusText);
      console.log(response);
      return response.json();
    } catch (error) {
      console.log(error);
    }
  }

  const { id } = useParams();
  let albumData;

  if (!album) {
    return null;
  }
  const albums = album.filter((data) => data.userId === parseInt(id));

  if (id) {
    albumData = albums.map((data) => (
      <div className="album" key={data.id}>
        {data.title}
      </div>
    ));
  } else {
    albumData = album.map((data) => (
      <div className="album" key={data.id}>
        {data.title}
      </div>
    ));
  }

  return (
    <div className="grid">
      <h1>Albums</h1>
      {albumData}
    </div>
  );
}
export default AlbumDetails;
